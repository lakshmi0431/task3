-- Final Analysis Queries
-- Highest Spending Customer
SELECT
customers.customer_name,
SUM(orders.total_amount) AS TotalSpent
FROM customers
JOIN orders
ON customers.customer_id=orders.customer_id
GROUP BY customers.customer_name
ORDER BY TotalSpent DESC;
-- Monthly Sales
SELECT MONTH(order_date) AS Month, SUM(total_amount) AS Sales FROM orders GROUP BY MONTH(order_date);
-- Pending Payments
SELECT * FROM payments WHERE payment_status='Pending';
-- Out of Stock Products
SELECT * FROM products WHERE stock=0;