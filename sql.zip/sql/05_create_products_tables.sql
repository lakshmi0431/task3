CREATE TABLE products(
product_id INT PRIMARY KEY AUTO_INCREMENT,
product_name VARCHAR(100),
category_id INT,
price DECIMAL(10,2),
stock INT,
FOREIGN KEY(category_id)
REFERENCES categories(category_id)
);
