-- SELECT
SELECT * FROM customers;
-- WHERE
SELECT * FROM customers WHERE city='Hyderabad';
-- ORDER BY
SELECT * FROM products ORDER BY price DESC;
-- GROUP BY
SELECT customer_id, COUNT(order_id) AS TotalOrders FROM orders GROUP BY customer_id;
-- Average
SELECT AVG(price) FROM products;
-- Highest
SELECT MAX(price) FROM products;
-- Lowest
SELECT MIN(price) FROM products;
-- Revenue
SELECT SUM(total_amount) FROM orders;
