-- Multiple Table JOIN
SELECT
customers.customer_name,
products.product_name,
order_items.quantity,
orders.order_date
FROM orders
INNER JOIN customers
ON orders.customer_id=customers.customer_id
INNER JOIN order_items
ON orders.order_id=order_items.order_id
INNER JOIN products
ON order_items.product_id=products.product_id;