-- Subqueries
-- Products above average price
SELECT *
FROM products
WHERE price>(
SELECT AVG(price)
FROM products
);
-- Customers with more than two orders
SELECT customer_name
FROM customers
WHERE customer_id IN
(
SELECT customer_id
FROM orders
GROUP BY customer_id
HAVING COUNT(*)>2
);