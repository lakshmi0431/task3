-- Aggregate Analysis
-- Sales by Category
SELECT
categories.category_name,
SUM(order_items.quantity*order_items.price)
AS TotalSales
FROM order_items
JOIN products
ON order_items.product_id=products.product_id
JOIN categories ON products.category_id=categories.category_id
GROUP BY categories.category_name;
-- Top Selling Products
SELECT
products.product_name, SUM(order_items.quantity) AS QuantitySold FROM products JOIN order_items
ON products.product_id=order_items.product_id
GROUP BY products.product_name
ORDER BY QuantitySold DESC;