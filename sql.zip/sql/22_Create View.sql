-- Create View
-- CREATE VIEW customer_orders AS
-- SELECT
-- customers.customer_name,
-- orders.order_id,
-- orders.total_amount
-- FROM customers
-- JOIN orders
-- ON customers.customer_id=orders.customer_id;

SELECT * FROM customer_orders;