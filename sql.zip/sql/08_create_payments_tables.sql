CREATE TABLE payments(
payment_id INT PRIMARY KEY AUTO_INCREMENT,
order_id INT,
payment_method VARCHAR(50),
payment_status VARCHAR(50),
FOREIGN KEY(order_id)
REFERENCES orders(order_id)
);