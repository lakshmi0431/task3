-- INNER JOIN
SELECT customers.customer_name,
orders.order_id,
orders.total_amount
FROM customers
INNER JOIN orders
ON customers.customer_id=orders.customer_id;